# restaurant-ordering-system

Watch Youtube video for set up, run, and demo

https://www.youtube.com/watch?v=Yf8zB4dXp7I

Give a star if you like it!
